import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {


  constructor(private _http:HttpClient) { }
  public loginUser(token:any){
    localStorage.setItem("token",token);
    console.log(localStorage.getItem("token"));
    //return true;
  }

  public getCurrentUser(user: any) {
    return this._http.post(`http://localhost:8083/registration/login`,user);
    //throw new Error('Method not implemented.');
  }
  public setUser(user: any) {
    
  }
 public generateToken(loginData: { username: string; password: string; }) {
  return this._http.post(`/registration/login`,loginData);
  }
}
