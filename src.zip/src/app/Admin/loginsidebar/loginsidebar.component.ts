import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginsidebar',
  templateUrl: './loginsidebar.component.html',
  styleUrls: ['./loginsidebar.component.css']
})
export class LoginsidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
