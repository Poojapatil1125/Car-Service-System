import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LogindashboardComponent } from './Admin/logindashboard/logindashboard.component';
import { UsersidebarComponent } from './Admin/usersidebar/usersidebar.component';
import { LoginComponent } from './Login/login/login.component';
import { AddMechanicsComponent } from './Registration/add-mechanics/add-mechanics.component';
import { AllResponseEnquiryComponent } from './Registration/all-response-enquiry/all-response-enquiry.component';
import { AllServiceComponent } from './Registration/all-service/all-service.component';
import { ChangePasswordComponent } from './Registration/change-password/change-password.component';
import { CompletedComponent } from './Registration/completed/completed.component';
import { CustomerEnquiryComponent } from './Registration/customer-enquiry/customer-enquiry.component';

import { DashboardComponent } from './Registration/dashboard/dashboard.component';
import { LogoutComponent } from './Registration/logout/logout.component';
import { ManageCategoryComponent } from './Registration/manage-category/manage-category.component';
import { ManageMechanicsComponent } from './Registration/manage-mechanics/manage-mechanics.component';
import { MechanicsComponent } from './Registration/mechanics/mechanics.component';
import { NavbarComponent } from './Registration/navbar/navbar.component';
import { NewServiceComponent } from './Registration/new-service/new-service.component';
import { NotResponseEnquiryComponent } from './Registration/not-response-enquiry/not-response-enquiry.component';
import { PendingComponent } from './Registration/pending/pending.component';
import { RegisterUserComponent } from './Registration/register-user/register-user.component';
import { RegistrationComponent } from './Registration/registration/registration.component';
import { RejectedServiceComponent } from './Registration/rejected-service/rejected-service.component';
import { ResponseEnquiryComponent } from './Registration/response-enquiry/response-enquiry.component';
import { ServiceRequestComponent } from './Registration/service-request/service-request.component';
import { ServicingComponent } from './Registration/servicing/servicing.component';
import { VehicleCategoryComponent } from './Registration/vehicle-category/vehicle-category.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'sidebar',component:UsersidebarComponent},
  {path:'navbar',component:NavbarComponent},
  {path:'mechanics',component:MechanicsComponent},
    {
    path:'registration',
    component:RegistrationComponent,
 
  children:[
    {
      path:'dashboard',
      component:DashboardComponent,
      

    },
    {
      path:'mechanics',
      component:MechanicsComponent
    },
    {
      path:'addmechanics',
      component:AddMechanicsComponent
    },
    {
      path:'managemechanics',
      component:ManageMechanicsComponent
    },
    {
      path:'vehicle-category',
      component:VehicleCategoryComponent
    },
    {
      path:'managecategory',
      component:ManageCategoryComponent
    },
    {
      path:'register-user',
      component:RegisterUserComponent
    },
    {
      path:'service-request',
      component:ServiceRequestComponent
    },
    {
      path:'newservice',
      component:NewServiceComponent
    },
    {
      path:'rejectedservice',
      component:RejectedServiceComponent
    },
    {
      path:'servicing',
      component:ServicingComponent
    },
    {
      path:'pending',
      component:PendingComponent
    },
    {
      path:'completed',
      component:CompletedComponent
    },
    {
      path:'allservice',
      component:AllServiceComponent
    },
    {
      path:'customer-enquiry',
      component:CustomerEnquiryComponent
    },
    {
      path:'not-response-enquiry',
      component:NotResponseEnquiryComponent
    },
    {
      path:'response-enquiry',
      component:ResponseEnquiryComponent
    },
    {
      path:'all-response-enquiry',
      component:AllResponseEnquiryComponent
    },
    {
      path:'change-password',
      component:ChangePasswordComponent
    },
    {
      path:'logout',
      component:LogoutComponent
    },
  ]
},
{path:'login',
component:LoginComponent},
  {
    path:'loginuser',
  component:LogindashboardComponent,

  children:[
    {
      path:'logindashboard',
      component:LogindashboardComponent,
    }
  ],
}

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
