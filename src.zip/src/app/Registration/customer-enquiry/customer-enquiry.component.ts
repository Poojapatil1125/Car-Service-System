import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-enquiry',
  templateUrl: './customer-enquiry.component.html',
  styleUrls: ['./customer-enquiry.component.css']
})
export class CustomerEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
