import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-request',
  templateUrl: './service-request.component.html',
  styleUrls: ['./service-request.component.css']
})
export class ServiceRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
