import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-manage-mechanics',
  templateUrl: './manage-mechanics.component.html',
  styleUrls: ['./manage-mechanics.component.css']
})
export class ManageMechanicsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
