import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageMechanicsComponent } from './manage-mechanics.component';

describe('ManageMechanicsComponent', () => {
  let component: ManageMechanicsComponent;
  let fixture: ComponentFixture<ManageMechanicsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageMechanicsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageMechanicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
