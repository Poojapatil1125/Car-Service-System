import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-response-enquiry',
  templateUrl: './all-response-enquiry.component.html',
  styleUrls: ['./all-response-enquiry.component.css']
})
export class AllResponseEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
