import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-service',
  templateUrl: './all-service.component.html',
  styleUrls: ['./all-service.component.css']
})
export class AllServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
