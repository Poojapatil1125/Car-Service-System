import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejected-service',
  templateUrl: './rejected-service.component.html',
  styleUrls: ['./rejected-service.component.css']
})
export class RejectedServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
