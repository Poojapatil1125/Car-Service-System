import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-category',
  templateUrl: './vehicle-category.component.html',
  styleUrls: ['./vehicle-category.component.css']
})
export class VehicleCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
