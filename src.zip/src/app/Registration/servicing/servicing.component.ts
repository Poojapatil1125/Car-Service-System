import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicing',
  templateUrl: './servicing.component.html',
  styleUrls: ['./servicing.component.css']
})
export class ServicingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
