import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-mechanics',
  templateUrl: './add-mechanics.component.html',
  styleUrls: ['./add-mechanics.component.css']
})
export class AddMechanicsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
