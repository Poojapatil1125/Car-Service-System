import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-response-enquiry',
  templateUrl: './response-enquiry.component.html',
  styleUrls: ['./response-enquiry.component.css']
})
export class ResponseEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
