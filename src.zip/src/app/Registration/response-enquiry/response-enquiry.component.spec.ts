import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResponseEnquiryComponent } from './response-enquiry.component';

describe('ResponseEnquiryComponent', () => {
  let component: ResponseEnquiryComponent;
  let fixture: ComponentFixture<ResponseEnquiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResponseEnquiryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResponseEnquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
