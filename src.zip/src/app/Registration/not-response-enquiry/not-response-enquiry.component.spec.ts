import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotResponseEnquiryComponent } from './not-response-enquiry.component';

describe('NotResponseEnquiryComponent', () => {
  let component: NotResponseEnquiryComponent;
  let fixture: ComponentFixture<NotResponseEnquiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotResponseEnquiryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NotResponseEnquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
