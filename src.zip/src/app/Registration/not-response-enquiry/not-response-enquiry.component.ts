import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-response-enquiry',
  templateUrl: './not-response-enquiry.component.html',
  styleUrls: ['./not-response-enquiry.component.css']
})
export class NotResponseEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
