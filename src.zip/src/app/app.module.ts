import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {MatToolbarModule} from '@angular/material/toolbar';

import {MatIconModule} from '@angular/material/icon';

import {MatCardModule} from '@angular/material/card';

import {MatListModule} from '@angular/material/list';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatButtonModule} from '@angular/material/button';

import {MatInputModule} from '@angular/material/input';

import {MatFormFieldModule} from '@angular/material/form-field';

import {MatSelectModule} from '@angular/material/select';
import { RegistrationComponent } from './Registration/registration/registration.component';
import { AdminSidebarComponent } from './Registration/admin-sidebar/admin-sidebar.component';
import { NavbarComponent } from './Registration/navbar/navbar.component';
import { DashboardComponent } from './Registration/dashboard/dashboard.component';
import { MechanicsComponent } from './Registration/mechanics/mechanics.component';
import { LoginComponent } from './Login/login/login.component';
import { VehicleCategoryComponent } from './Registration/vehicle-category/vehicle-category.component';
import { RegisterUserComponent } from './Registration/register-user/register-user.component';
import { ServiceRequestComponent } from './Registration/service-request/service-request.component';
import { ServicingComponent } from './Registration/servicing/servicing.component';
import { CustomerEnquiryComponent } from './Registration/customer-enquiry/customer-enquiry.component';
import { AddMechanicsComponent } from './Registration/add-mechanics/add-mechanics.component';
import { ManageMechanicsComponent } from './Registration/manage-mechanics/manage-mechanics.component';
import { AddCategoryComponent } from './Registration/add-category/add-category.component';
import { ManageCategoryComponent } from './Registration/manage-category/manage-category.component';
import {MatExpansionModule} from '@angular/material/expansion';
import { NewServiceComponent } from './Registration/new-service/new-service.component';
import { RejectedServiceComponent } from './Registration/rejected-service/rejected-service.component';
import { PendingComponent } from './Registration/pending/pending.component';
import { CompletedComponent } from './Registration/completed/completed.component';
import { AllServiceComponent } from './Registration/all-service/all-service.component';
import { NotResponseEnquiryComponent } from './Registration/not-response-enquiry/not-response-enquiry.component';
import { ResponseEnquiryComponent } from './Registration/response-enquiry/response-enquiry.component';
import { AllResponseEnquiryComponent } from './Registration/all-response-enquiry/all-response-enquiry.component';
import { ChangePasswordComponent } from './Registration/change-password/change-password.component';
import { LogoutComponent } from './Registration/logout/logout.component';
import { LoginsidebarComponent } from './Admin/loginsidebar/loginsidebar.component';
import { LogindashboardComponent } from './Admin/logindashboard/logindashboard.component';
import { UsersidebarComponent } from './Admin/usersidebar/usersidebar.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    UsersidebarComponent,
    AdminSidebarComponent,
    NavbarComponent,
    DashboardComponent,
    MechanicsComponent,
    VehicleCategoryComponent,
    RegisterUserComponent,
    ServiceRequestComponent,
    ServicingComponent,
    CustomerEnquiryComponent,
    AddMechanicsComponent,
    ManageMechanicsComponent,
    AddCategoryComponent,
    ManageCategoryComponent,
    NewServiceComponent,
    RejectedServiceComponent,
    PendingComponent,
    CompletedComponent,
    AllServiceComponent,
    NotResponseEnquiryComponent,
    ResponseEnquiryComponent,
    AllResponseEnquiryComponent,
    ChangePasswordComponent,
    LogoutComponent,
    LoginsidebarComponent,
    LogindashboardComponent
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatListModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatExpansionModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
