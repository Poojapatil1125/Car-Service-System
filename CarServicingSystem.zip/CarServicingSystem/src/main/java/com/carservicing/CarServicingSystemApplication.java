package com.carservicing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarServicingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarServicingSystemApplication.class, args);
	}

}
